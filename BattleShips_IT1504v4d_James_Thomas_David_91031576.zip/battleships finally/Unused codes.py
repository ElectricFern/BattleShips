# Guess.py
# author:
# date: 04/12/2018
# from Board import Board
#
# class Guess:
#
#     player1 = Board()
#     player2 = Board()
#     def player_guess(self, player_number, board):
#         while player_number == 2:
#             if player_number == 2:
#                 self.player1 = board
#                 guess_x = int(input("Guess row\n"))
#                 guess_y = int(input("Guess column\n"))
#                 if self.player1.board[guess_x][guess_y] == "S":
#                     print("You hit one")
#             else:
#                 self.player2 = board
#                 guess_x = int(input("Guess row\n"))
#                 guess_y = int(input("Guess column\n"))
#                 if self.player2.board[guess_x][guess_y] == "S":
#                     print("You hit one")


# else:
#     self.player2 = board
#     guess_x = int(input("Guess row\n"))
#     guess_y = int(input("Guess column\n"))
#     if self.player2.board[guess_x][guess_y] == "S":
#         print("You hit one")
